//
// Created by Bogdan Madzhuga on 24.09.2023.
//

#ifndef PRACTICE3_POSITION_H
#define PRACTICE3_POSITION_H

#endif //PRACTICE3_POSITION_H


struct ScreenPosition {
    int x = 0, y = 0;
};
