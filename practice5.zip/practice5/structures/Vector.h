//
// Created by Bogdan Madzhuga on 23.09.2023.
//

#ifndef PRACTICE3_VECTOR_H
#define PRACTICE3_VECTOR_H

#endif //PRACTICE3_VECTOR_H

struct Vector {
    float x, y, z, w;
};
